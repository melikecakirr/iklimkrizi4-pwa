export async function fetchPosts() {
  const res = await fetch("https://iklimkrizi4.wordpress.com/wp-json/wp/v2/posts?_embed");
  const posts = await res.json();
  return posts;
}

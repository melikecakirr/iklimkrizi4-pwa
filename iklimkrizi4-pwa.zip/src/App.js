import { fetchPosts } from "./api.js";

document.addEventListener("DOMContentLoaded", async () => {
  const root = document.getElementById("root");
  root.innerHTML = "<h1>İklimkrizi4</h1><p>Yükleniyor...</p>";

  try {
    const posts = await fetchPosts();
    root.innerHTML = posts
      .map(post => `
        <article>
          <h2>${post.title.rendered}</h2>
          <div>${post.excerpt.rendered}</div>
          <a href="${post.link}" target="_blank">Devamını oku</a>
        </article>
      `)
      .join("");
  } catch (err) {
    root.innerHTML = "<p>İçerik yüklenemedi.</p>";
  }
});
